import React, { useState, useRef, useEffect } from 'react';
// import { FaBars } from 'react-icons/fa';

const Navbar = () => {
  const [showLinks, setShowLinks] = useState(false);
  const linksContainerRef = useRef(null);
  const linksRef = useRef(null);
  const toggleLinks = () => {
    setShowLinks(!showLinks);
  };
  useEffect(() => {
    const linksHeight = linksRef.current.getBoundingClientRect().height;
    if (showLinks) {
      linksContainerRef.current.style.height = `${linksHeight}px`;
    } else {
      linksContainerRef.current.style.height = '0px';
    }
  }, [showLinks]);
  return (
    <nav>
      <div className='nav-center'>
        <div className='nav-header'>
          
          <h4 style={{color: 'white'}}>Send Freight</h4>
          <button className='nav-toggle' onClick={toggleLinks}>
            {/* <FaBars /> */}
            <i class="fa fa-bars"></i>
          </button>
        </div>
        <div className='links-container topnav' ref={linksContainerRef}>
          <ul className='links' ref={linksRef}>
          <div style={{marginRight: '140px'}}>
    <form action="/action_page.php">
      <input className="form-control" type="text" placeholder="Search" size name="search"/>
    </form>
  </div>
  <div style={{marginRight: '20px', marginTop: '5px'}}>
    <form action="/action_page.php">
      <button className="form-control" type="button" className="btn-quote"  name="search">Request Quote</button>
    </form>
  </div>
  <div style={{marginTop: '5px', marginBottom: '5px'}}>
    <form action="/action_page.php" className="form-group">
      <button className="form-control" type="button" className="btn-booking" name="search">Book Shipment</button>
    </form>
  </div>
          </ul>
        </div>
      </div>
    </nav>
  );
};

export default Navbar;
