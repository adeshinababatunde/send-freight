import './App.css';
import Navbar from './Navbar';
import 'bootstrap/dist/css/bootstrap.min.css'

function App() {
  return (
    <div className="body">
          

<Navbar></Navbar>


    <div className="section section-booking">
      <div className="container">
      <div className="row">
        <div className="service-icon col-sm-12 col-md-4 col-lg-2">
            <i class="fa fa-arrow-left"></i>
      </div>
      <div className="service-booking col-sm-12 col-md-8 col-lg-10">
      <h4>New Booking</h4>
      <p>Fill in the information below to get a quote or create a new booking</p>
      </div>
      </div>
      </div>
    </div>

    <div className="section">
    <div className="container col-sm-12 col-md-12 col-lg-12">
      <div className="row">
        <div className="col-sm-4 col-md-2 col-lg-2">
          <span></span>
      </div>
      <div className="section-service col-sm-8 col-md-10 col-lg-10">
      <div className="row">
      <h5>Select a service</h5>
     
        <div className="service-card-air col-sm-12 col-md-12 col-lg-2">
          <div className="row">
            <div className="col-sm-6 col-md-6 lg-9">
              <p>Air Freight</p>
            </div>
            <div className="col-sm-6 col-md-6 lg-3">
            <i className="material-icons freight-icon" style={{marginRight: '-25px'}}>airplanemode_active</i>
            </div>
          </div>
        </div>
        <div className="service-card col-sm-12 col-md-12 col-lg-3">
        <div className="row">
            <div className="col-sm-6 col-md-6 lg-9">
            <p>Sea Freight</p>
            </div>
            <div className="col-sm-6 col-md-6 lg-3">
            
            <i class="fa fa-ship freight-icon"></i>
            </div>
          </div>
        </div>
        <div className="service-card col-sm-12 col-md-12 col-lg-3">
        <div className="row">
            <div className="col-sm-6 col-md-6 lg-9">
            <p>Inland <br/>
          (Truck & Barge)</p>
            </div>
            <div className="col-sm-6 col-md-6 lg-3">
            <i className="fas fa-truck freight-icon"></i>
            </div>
          </div>
          
        </div>
        <div className="service-card col-sm-12 col-md-12 col-lg-3">
        <div className="row">
            <div className="col-sm-6 col-md-6 lg-9">
            <p>Customs<br/>Clearance</p>
            </div>
            <div className="col-sm-6 col-md-6 lg-3">
            <i class="fa fa-user-secret freight-icon"></i>
            </div>
          </div>
          
        </div>
      </div>
      </div>
      </div>
      </div>
      </div>

      <div className="section">
    <div className="container">
      <div className="row">
      <div className="service-icon col-sm-4 col-md-2 col-lg-2">
          <span></span>
      </div>
      <div className="section-service col-sm-8 col-md-10 col-lg-10">
      <div className="row" style={{paddingBottom: '30px'}}>
        <i class="fa fa-exclamation-circle"></i><br/>
        <div className="file-card col-sm-8 col-md-10 col-lg-3">
          <input type="button" value="Import"/>
          <input type="button" value="Export"/>
        </div>
        <div className=" col-sm-8 col-md-10 col-lg-4">
        {/* <i class="fa fa-map-marker icon"></i> */}
        <div class="input-icons">
            <i class="fa fa-map-marker icon"></i>
            <input type="text" className="form-control input-field" placeholder="From City or port"/>
            </div>
        </div>
        <div className="col-sm-8 col-md-10 col-lg-4">
        <div class="input-icons">
            <i class="fa fa-map-marker icon"></i>
       <input type="text" className="form-control input-field" placeholder="To City or port"/>
       </div>
        </div>
      </div>
      <div className="row">
        <div className="location-card col-sm-8 col-md-10 col-lg-3"> 
        <div class="input-icons">
            <i class="fa fa-calendar icon"></i>
          <input type="text" className="form-control input-field" placeholder="Ready Date" />
          </div>
        </div>
        <div className="location-card col-sm-8 col-md-10 col-lg-3">
        <div class="input-icons">
            <i class="fa fa-caret-down icon"></i>
          <select className="form-control input-field" value="Select City">
            <option value="Incoterms">Incoterms</option>
            <option value="Las Vegas">Las Vegas</option>
          </select>
          </div>
        </div>
        <div className="location-card col-sm-8 col-md-10 col-lg-3">
        <input type="text" className="form-control" placeholder="Total Cargo Value"/>
        </div>
      </div>
      </div>
      </div>
      </div>
      </div>


      <div className="section">
    <div className="container">
      <div className="row">
      <div className="service-icon col-sm-4 col-md-2 col-lg-2">
          <span></span>
      </div>
      <div className="section-service col-sm-8 col-md-10 col-lg-10">
    <div className="row">
        <div className="file-card col-sm-12 col-md-6 col-lg-7">
      <h5>Cargo Details</h5>
        </div>
        
        <div className="col-sm-12 col-md-3 col-lg-1">
        <label className="switch">
        <input type="checkbox"/>
        <span className="slider round"></span>
        </label> 
        </div>
       <div className="col-sm-12 col-md-3 col-lg-4">
       <p>  Dangerous Cargo (ex. Chemicals, Battery)</p>
        </div><br/>
    </div>
      <div className="row">
        <div className="file-card col-sm-12 col-md-12 col-lg-6">
        <div className="tab">
      <button className="tablinks active">Total Dimensions</button>
          <button className="tablinks">Package Details</button>
      </div>
        </div>
        <div>
        </div>
      </div><br/><br/>
      <div className="row">
        <div className="location-card col-sm-12 col-md-6 col-lg-3"> 
          <input type="text" className="form-control" placeholder="Ready Date" />
        </div>
        <div className="location-card col-sm-12 col-md-6 col-lg-3">
        <input type="text" className="form-control" placeholder="Total Cargo Value"/>
        </div>
      </div>
      </div>
      </div>
      </div>
      </div>

      <div className="section">
    <div className="container">
      <div className="row">
      <div className="service-icon col-sm-4 col-md-2 col-lg-2">
          <span></span>
      </div>
      <div className="section-service col-sm-8 col-md-10 col-lg-10">
        <div>
        <h4>Additional Services</h4><br/>
        </div>
      
      <div className="additional-service-grid row">
     
        <div className="col-sm-12 col-md-3 col-lg-1">
        <label className="switch">
        <input type="checkbox"/>
        <span className="slider round"></span>
        </label> 
        </div>
       <div className="col-sm-12 col-md-3 col-lg-5">
       <h5>Export Forwarding</h5>
       <p>We handle customs Clearance and documentation.</p>
        </div><br/>
        
        <div className="col-sm-12 col-md-3 col-lg-1">
        <label className="switch">
        <input type="checkbox"/>
        <span className="slider round"></span>
        </label> 
        </div>
       <div className="col-sm-12 col-md-3 col-lg-5">
         <h5>Import Custom Clearance</h5>
       <p>We handle import customs and regulatory requirements.</p>
        </div><br/>
        <div className="col-sm-12 col-md-3 col-lg-1">
        <label className="switch">
        <input type="checkbox"/>
        <span className="slider round"></span>
        </label> 
        </div>
       <div className="col-sm-12 col-md-3 col-lg-5">
       <h5>Cargo Insurance</h5>
       <p>Protect your cargo from logistics risks up to its full value.</p>
        </div><br/>
        <div className="col-sm-12 col-md-3 col-lg-1">
        <label className="switch">
        <input type="checkbox"/>
        <span className="slider round"></span>
        </label> 
        </div>
       <div className="col-sm-12 col-md-3 col-lg-5">
         <h6>Transport/Delivery</h6>
       <p>We deliver the cargo to your door step from the ports.</p>
        </div><br/>
  
      </div>
      </div>
      </div>
      </div>
      </div>



  </div>   
  );
}

export default App;
